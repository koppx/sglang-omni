# SPDX-License-Identifier: Apache-2.0
"""Temporary PR2330 experiment: measure one non-streaming SeedTTS cohort."""

from __future__ import annotations

import argparse
import asyncio
import base64
import binascii
import hashlib
import io
import json
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path

import aiohttp
import numpy as np
import soundfile as sf
from pydantic import BaseModel, ValidationError

from benchmarks.dataset.seedtts import load_seedtts_samples

FULL_EN_COUNT = 1088
WARMUP_COUNT = 16


class AudioResponse(BaseModel):
    data: str


class MessageResponse(BaseModel):
    audio: AudioResponse


class ChoiceResponse(BaseModel):
    message: MessageResponse
    finish_reason: str | None = None


class ChatResponse(BaseModel):
    id: str
    choices: list[ChoiceResponse]


@dataclass(kw_only=True)
class PreparedSample:
    sample_id: str
    target_text: str
    reference_sha256: str
    payload: bytes
    request_id: str


@dataclass(kw_only=True)
class RequestRecord:
    sample_id: str
    target_text: str
    request_id: str
    response_id: str = ""
    start_ns: int = 0
    body_ns: int = 0
    ready_ns: int = 0
    http_s: float = 0.0
    ready_s: float = 0.0
    audio_s: float = 0.0
    finish_reason: str | None = None
    error: str = ""


def prepare(meta: Path, count: int, language: str) -> list[PreparedSample]:
    samples = load_seedtts_samples(str(meta.absolute()), split=language)
    if len(samples) < count or (language == "en" and len(samples) != FULL_EN_COUNT):
        raise ValueError(f"Unexpected sample count in {meta}: {len(samples)}")
    if len({sample.sample_id for sample in samples}) != len(samples):
        raise ValueError(f"Duplicate sample IDs in {meta}")
    prepared = []
    for sample in samples[:count]:
        reference = Path(sample.ref_audio).read_bytes()
        request_id = str(uuid.uuid4())
        # Match VoiceCloneOmni's audio.ref_audio prompt without timed file I/O.
        prefix = (
            "Please read the following text out loud in English: "
            if language == "en"
            else "\u8bf7\u7528\u4e2d\u6587\u6717\u8bfb\u4ee5\u4e0b\u6587\u672c: "
        )
        payload = {
            "model": "MiniCPM-o-4_5",
            "request_id": request_id,
            "messages": [{"role": "user", "content": prefix + sample.target_text}],
            "modalities": ["text", "audio"],
            "audio": {
                "format": "wav",
                "ref_audio": "data:audio/wav;base64,"
                + base64.b64encode(reference).decode("ascii"),
            },
            "max_tokens": 256,
            "temperature": 0.7,
            "stream": False,
        }
        prepared.append(
            PreparedSample(
                sample_id=sample.sample_id,
                target_text=sample.target_text,
                reference_sha256=hashlib.sha256(reference).hexdigest(),
                payload=json.dumps(payload).encode(),
                request_id=request_id,
            )
        )
    return prepared


async def measure(
    samples: list[PreparedSample], concurrency: int, url: str, timeout: float
) -> tuple[list[RequestRecord], list[bytes], float]:
    records = [
        RequestRecord(
            sample_id=sample.sample_id,
            target_text=sample.target_text,
            request_id=sample.request_id,
        )
        for sample in samples
    ]
    waveforms = [b""] * len(samples)
    queue = iter(enumerate(samples))
    connector = aiohttp.TCPConnector(limit=concurrency)
    async with aiohttp.ClientSession(
        connector=connector, timeout=aiohttp.ClientTimeout(total=timeout)
    ) as session:

        async def worker() -> None:
            for index, sample in queue:
                record = records[index]
                record.start_ns = time.time_ns()
                start = time.perf_counter()
                try:
                    async with session.post(
                        url,
                        data=sample.payload,
                        headers={"Content-Type": "application/json"},
                    ) as response:
                        body = await response.read()
                        record.http_s = time.perf_counter() - start
                        record.body_ns = time.time_ns()
                        if response.status != 200:
                            raise ValueError(f"HTTP {response.status}: {body[:500]!r}")
                    decoded = ChatResponse.model_validate_json(body)
                    record.response_id = decoded.id
                    if not decoded.choices:
                        raise ValueError("Empty choices")
                    choice = decoded.choices[0]
                    waveform = base64.b64decode(
                        choice.message.audio.data, validate=True
                    )
                    audio, sample_rate = sf.read(io.BytesIO(waveform), dtype="float32")
                    record.ready_s = time.perf_counter() - start
                    record.ready_ns = time.time_ns()
                    if len(audio) == 0 or not np.isfinite(audio).all():
                        raise ValueError("Empty or non-finite audio")
                    record.audio_s = len(audio) / sample_rate
                    record.finish_reason = choice.finish_reason
                    waveforms[index] = waveform
                except (
                    aiohttp.ClientError,
                    asyncio.TimeoutError,
                    ValueError,
                    RuntimeError,
                    binascii.Error,
                    ValidationError,
                ) as error:
                    record.error = f"{type(error).__name__}: {error}"

        started = time.perf_counter()
        await asyncio.gather(*(worker() for _ in range(concurrency)))
        wall_s = time.perf_counter() - started
    return records, waveforms, wall_s


def summarize(records: list[RequestRecord], wall_s: float) -> dict[str, float | int]:
    successful = [record for record in records if not record.error]
    audio_s = sum(record.audio_s for record in successful)
    summary = {
        "attempted": len(records),
        "successful": len(successful),
        "failed": len(records) - len(successful),
        "wall_s": wall_s,
        "req_s": len(successful) / wall_s,
        "audio_s_s": audio_s / wall_s,
        "audio_total_s": audio_s,
        "length_finishes": sum(
            record.finish_reason == "length" for record in successful
        ),
    }
    if successful:
        summary["audio_mean_s"] = audio_s / len(successful)
        for name, values in (
            ("http", [record.http_s for record in successful]),
            ("ready", [record.ready_s for record in successful]),
        ):
            summary[f"{name}_mean_s"] = float(np.mean(values))
            summary[f"{name}_max_s"] = max(values)
            for percentile in (50, 95, 99):
                summary[f"{name}_p{percentile}_s"] = float(
                    np.percentile(values, percentile)
                )
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--meta", type=Path, required=True)
    parser.add_argument("--warmup-meta", type=Path, required=True)
    parser.add_argument("--url", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--concurrency", type=int, required=True)
    parser.add_argument("--samples", type=int, default=FULL_EN_COUNT)
    parser.add_argument("--timeout", type=float, default=300)
    arguments = parser.parse_args()
    if not 0 < arguments.samples <= FULL_EN_COUNT or arguments.concurrency < 1:
        parser.error("Require 1..1088 samples and positive concurrency")
    if arguments.timeout <= 0:
        parser.error("Timeout must be positive")
    arguments.output.mkdir(parents=True, exist_ok=False)
    samples = prepare(arguments.meta, arguments.samples, "en")
    warmup = prepare(arguments.warmup_meta, WARMUP_COUNT, "zh")
    if {sample.reference_sha256 for sample in samples} & {
        sample.reference_sha256 for sample in warmup
    }:
        raise ValueError("Warmup and measurement must use independent references")
    manifest = {
        phase: [
            {
                "sample_id": sample.sample_id,
                "target_text": sample.target_text,
                "reference_sha256": sample.reference_sha256,
            }
            for sample in cohort
        ]
        for phase, cohort in (("measured", samples), ("warmup", warmup))
    }
    manifest_bytes = json.dumps(manifest, sort_keys=True).encode()
    (arguments.output / "inputs.json").write_bytes(manifest_bytes)
    for phase, cohort in (("warmup", warmup), ("measured", samples)):
        records, waveforms, wall_s = asyncio.run(
            measure(cohort, arguments.concurrency, arguments.url, arguments.timeout)
        )
        with (arguments.output / f"{phase}.jsonl").open("x") as output:
            for record in records:
                output.write(json.dumps(asdict(record)) + "\n")
        audio_directory = arguments.output / phase
        audio_directory.mkdir()
        for index, waveform in enumerate(waveforms):
            if waveform:
                (audio_directory / f"{index:04d}.wav").write_bytes(waveform)
        summary = summarize(records, wall_s)
        summary.update(
            concurrency=arguments.concurrency,
            inputs_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
            smoke=arguments.samples != FULL_EN_COUNT,
        )
        (arguments.output / f"{phase}.json").write_text(
            json.dumps(summary, indent=2) + "\n"
        )
        if summary["failed"]:
            raise SystemExit(f"{phase} failed; results retained in {arguments.output}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
