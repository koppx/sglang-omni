# SPDX-License-Identifier: Apache-2.0
"""Measure actual Talker condition construction and prefill packing methods."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import statistics
import subprocess
import time
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn.functional as F
from torch import nn

import sglang_omni
from sglang_omni.model_runner.prefill_inputs import get_omni_prefill_inputs
from sglang_omni.models.minicpm_o.components.sglang_talker import (
    MiniCPMOTalkerForCausalLM,
    MiniCPMTTSProjector,
)
from sglang_omni.models.minicpm_o.talker_model_runner import MiniCPMOTalkerModelRunner

SEED = 2330


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--input-device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument(
        "--dtype", choices=("float32", "bfloat16", "float16"), default="bfloat16"
    )
    parser.add_argument("--lengths", type=int, nargs="+", default=[0, 32, 128, 256])
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 4, 16])
    parser.add_argument("--samples", type=int, default=200)
    parser.add_argument("--warmup", type=int, default=50)
    arguments = parser.parse_args()
    if (
        min(arguments.lengths) < 0
        or min(arguments.batches) < 1
        or arguments.samples < 20
        or arguments.warmup < 1
    ):
        parser.error(
            "Require nonnegative lengths, positive batches/warmup and >=20 samples"
        )
    if arguments.output.exists():
        parser.error("Choose a new output file")
    if not torch.cuda.is_available():
        parser.error("CUDA is required")
    configuration = json.loads(arguments.config.read_text())["tts_config"]
    torch.manual_seed(SEED)
    torch.set_num_threads(4)
    dtype = getattr(torch, arguments.dtype)
    model = MiniCPMOTalkerForCausalLM.__new__(MiniCPMOTalkerForCausalLM)
    nn.Module.__init__(model)
    model.text_eos_token_id = int(configuration["text_eos_token_id"])
    model.audio_bos_token_id = int(configuration["audio_bos_token_id"])
    model.normalize_projected_hidden = bool(
        configuration.get("normalize_projected_hidden", True)
    )
    hidden_size = int(configuration["hidden_size"])
    model.emb_text = nn.Embedding(int(configuration["num_text_tokens"]), hidden_size)
    model.emb_code = nn.Embedding(int(configuration["num_audio_tokens"]), hidden_size)
    model.projector_semantic = MiniCPMTTSProjector(
        int(configuration["llm_dim"]), hidden_size
    )
    model.to(device="cuda", dtype=dtype).eval()
    runner = MiniCPMOTalkerModelRunner.__new__(MiniCPMOTalkerModelRunner)
    runner.model = model
    cases = []
    matrix = [
        (length, batch) for length in arguments.lengths for batch in arguments.batches
    ]
    random.Random(SEED).shuffle(matrix)
    with torch.inference_mode():
        for length, batch in matrix:
            tokens = torch.randint(
                0,
                int(configuration["num_text_tokens"]),
                (length,),
                device=arguments.input_device,
            )
            hidden = torch.randn(
                length,
                int(configuration["llm_dim"]),
                device=arguments.input_device,
                dtype=dtype,
            )
            boundary = model.emb_text(
                torch.tensor(
                    [model.text_eos_token_id, model.audio_bos_token_id], device="cuda"
                )
            )
            projected = model.projector_semantic(hidden.to("cuda"))
            if model.normalize_projected_hidden:
                projected = F.normalize(projected, p=2, dim=-1)
            expected_condition = torch.cat(
                (model.emb_text(tokens.to("cuda")) + projected, boundary)
            )
            condition = model.build_condition_embeddings(tokens, hidden)
            torch.testing.assert_close(condition, expected_condition, rtol=0, atol=0)
            requests = [
                SimpleNamespace(
                    data=SimpleNamespace(
                        prefill_input_embeds=condition,
                        req=SimpleNamespace(
                            prefix_indices=[],
                            extend_range=SimpleNamespace(length=length + 2),
                        ),
                    )
                )
                for _ in range(batch)
            ]
            forward_batch = SimpleNamespace(
                input_ids=torch.zeros(
                    batch * (length + 2), device="cuda", dtype=torch.long
                ),
                replace_embeds=None,
            )
            expected_packed = torch.cat([condition] * batch)
            for operation in ("condition", "packing"):

                def step() -> torch.Tensor:
                    if operation == "condition":
                        for _ in range(batch):
                            result = model.build_condition_embeddings(tokens, hidden)
                        return result
                    else:
                        runner.before_prefill(forward_batch, None, requests)
                        prepared = get_omni_prefill_inputs(forward_batch)
                        assert prepared is not None
                        return prepared.input_embeds

                expected = (
                    expected_condition if operation == "condition" else expected_packed
                )
                torch.testing.assert_close(step(), expected, rtol=0, atol=0)
                for _ in range(arguments.warmup):
                    step()
                timings = []
                for _ in range(arguments.samples):
                    torch.cuda.synchronize()
                    started = time.perf_counter_ns()
                    step()
                    torch.cuda.synchronize()
                    timings.append((time.perf_counter_ns() - started) / 1000)
                cases.append(
                    {
                        "operation": operation,
                        "text_tokens": length,
                        "batch": batch,
                        "median_us": statistics.median(timings),
                        "p95_us": statistics.quantiles(
                            timings, n=100, method="inclusive"
                        )[94],
                        "wall_us": timings,
                    }
                )
    source = Path(sglang_omni.__file__).resolve().parents[1]
    result = {
        "source": str(source),
        "revision": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=source, text=True
        ).strip(),
        "source_sha256": {
            path: hashlib.sha256((source / path).read_bytes()).hexdigest()
            for path in (
                "sglang_omni/models/minicpm_o/components/sglang_talker.py",
                "sglang_omni/models/minicpm_o/talker_model_runner.py",
            )
        },
        "config_sha256": hashlib.sha256(arguments.config.read_bytes()).hexdigest(),
        "harness_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "gpu": torch.cuda.get_device_name(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda,
        "dtype": arguments.dtype,
        "input_device": arguments.input_device,
        "seed": SEED,
        "samples": arguments.samples,
        "warmup": arguments.warmup,
        "measurement": "Synchronized wall time per batch for actual methods with synthetic inputs and seeded random embedding/projector weights. No backbone forward, KV cache, retraction replay or serving scheduler. Not total Talker latency.",
        "correctness": "Exact comparison to reference embeddings passed for every case.",
        "cases": cases,
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    with arguments.output.open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(f"Saved {arguments.output}")


if __name__ == "__main__":
    main()
