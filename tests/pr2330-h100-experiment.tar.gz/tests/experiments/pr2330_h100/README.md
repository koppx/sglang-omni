# Temporary PR2330 single-H100 experiment

This directory is an out-of-tree experiment handoff, not a CI suite or a PR
change. Locally it is excluded through `.git/info/exclude`, which is not shared
by Git. Transfer this directory separately to the experiment machine under the
same path; fetching the branch will not download these files. Do not commit it.

This suite measures PR #2330 on one H100 with the workload described in
[issue #2273](https://github.com/sgl-project/sglang-omni/issues/2273).
It produces two **separate** comparisons:

1. A controlled local A/B: PR parent vs candidate, same machine and environment.
2. A historical reference: candidate vs the published issue table. This is not
   evidence that PR #2330 caused the difference.

The issue used commit `2d0b48ff4f00b3673c5ba94505ac2564bcc887c7` **plus a saved
profiling patch and added files**. Its patch hash is in `issue2273.json`.
That commit alone cannot reproduce the original source tree. The issue also
used mixed server reset policies and only one run per concurrency. Obtain its
evidence bundle before claiming an exact historical reproduction.

## Instructions for the experiment-machine AI

Run the commands below on Linux. Keep all raw outputs, including failed runs.
Do not change runtime settings to make only one variant pass. Do not run ASR,
another model, a profiler, or another experiment on the selected GPU during the
performance sweep. Do not silently substitute the Arrow dataset.

Use a dedicated H100 SXM 80 GB. The issue's environment was Python 3.12,
SGLang 0.5.19, Torch 2.13.0 (CUDA 13.0 build), Transformers 5.12.1,
ONNX 1.23.0, driver 580.159.04, and 26 allocated vCPUs. Match these when available;
otherwise record differences and treat historical deltas as contextual only.
Use one working MiniCPM-o environment for both checkouts. Install the repository
and its `minicpm-o` extra according to the repository installation instructions;
do not independently resolve or upgrade dependencies between A and B.
The client also needs `aiohttp`, `numpy`, `soundfile`, `pydantic>=2`, and
`huggingface_hub`; tests need `pytest`.

### 1. Prepare source and pinned artifacts

Start from the fork's `perf/minicpm-o-talker-repetition-penalty` branch and copy
this directory into it. Preserve any existing work; do not reset a checkout.

```bash
cd /path/to/sglang-omni
export CANDIDATE="$PWD"
export SUITE="$CANDIDATE/tests/experiments/pr2330_h100"
export BASELINE="$(dirname "$PWD")/sglang-omni-pr2330-parent"
git worktree add --detach "$BASELINE" 12f7b6670cc236b63cca4f53a9a495b9aea93cf5
git status --short
git rev-parse HEAD
git diff 12f7b6670cc236b63cca4f53a9a495b9aea93cf5 -- sglang_omni/models/minicpm_o

export MODEL="$(python -c 'from huggingface_hub import snapshot_download; print(snapshot_download("openbmb/MiniCPM-o-4_5", revision="503e754207c94da6bb26850b4469f367c9ea3582"))')"
export DATASET="$(python -c 'from huggingface_hub import snapshot_download; print(snapshot_download("zhaochenyang20/seed-tts-eval", repo_type="dataset", revision="8f5e1aa2a35d42f42e940074c1983358b9491f89"))')"
export META="$DATASET/en/meta.lst"
export WARMUP_META="$DATASET/zh/meta.lst"
export RESULTS="$(dirname "$PWD")/minicpm-h100-results"
```

The script reads the first 16 rows of `WARMUP_META` with Chinese prompts. The
original issue's 16 ZH hardcase IDs are not listed in its body. If the original
warmup manifest is available, use it here; otherwise the first 16 ZH rows are an
explicit **substitute**, shared by both variants. Record this in the final report.
Warmup references must not overlap measured references. No Chinese sweep runs.
Do not shuffle or edit metadata. All 1,088 English rows are required even for
input preparation; smoke mode measures only their first 8 rows.

### 2. Check correctness and smoke-test serving

```bash
cd "$CANDIDATE"
python -m pytest -q tests/unit_test/minicpm_o/test_sglang_talker.py
python -m pytest -q "$SUITE/test_harness.py"
python "$SUITE/run_ab.py" \
  --baseline "$BASELINE" --candidate "$CANDIDATE" \
  --model "$MODEL" --meta "$META" --warmup-meta "$WARMUP_META" \
  --output "$RESULTS/smoke" --gpu 0 --repeats 1 --samples 8 --concurrencies 1
```

The runner verifies the imported source path, selected H100, pinned model path,
and unused loopback port. Inspect `server.log` to confirm DP1, all stages on the
one visible GPU, Thinker context 8192, and memory fractions 0.55 / 0.15. The
default MiniCPM-o speech pipeline already places every stage on logical GPU 0.
`OMP_NUM_THREADS=4` is set for both variants. No profiling environment is enabled.
The runner requires Linux process groups and CPU affinity support.

### 3. Run the full comparison

```bash
python "$SUITE/run_ab.py" \
  --baseline "$BASELINE" --candidate "$CANDIDATE" \
  --model "$MODEL" --meta "$META" --warmup-meta "$WARMUP_META" \
  --output "$RESULTS/full-01" --gpu 0 --repeats 4
```

This sends 52,224 measured requests: 1,088 x 6 concurrency points x 2 variants
x 4 repetitions, plus warmup. Default concurrency is 1, 2, 4, 8, 16, 32. Every
point starts a fresh server and finishes its warmup before measurement.
Each repetition pairs A/B at each concurrency; even repetitions use B/A, so
each variant runs first equally often. Four repeats do not guarantee significance.
This is a consistent reset policy, not the issue's mixed-policy reproduction.
The last newly started server process group is stopped on success or failure.
Existing unrelated servers are not stopped.

A cohort with an OOM, timeout, missing audio, invalid WAV, or failed warmup stops
the sweep after that cohort finishes and retains evidence. Requests have a
300-second timeout; interrupt a persistently hung run and retain its server log.
Do not retry invisibly or exclude failures from the conclusion.
Use a **new output directory** after diagnosing a failure; output directories
are never overwritten or implicitly resumed. Save the failed attempt too.

### 4. Inspect results

`comparison.md` is generated automatically. Regenerate it with:

```bash
python "$SUITE/compare.py" "$RESULTS/full-01"
```

- `manifest.json`: commits, dirty diff/status, source paths, dependency versions,
  GPU/driver, CPU affinity, artifact revisions, arguments, harness hashes.
- `rN-cC-VARIANT/server.log` and `command.json`: exact launch and diagnostics.
- `client/inputs.json`: ordered sample IDs, full target text, reference hashes
  for both measured and warmup cohorts. Its hash must match across all points.
- `client/measured.jsonl`: request IDs, response IDs, timestamps, full text,
  timing, audio duration, finish reason and error. WAV filenames use the
  zero-based row index in this file, not the dataset sample ID.
- `client/measured.json`: metrics; `client/measured/*.wav`: generated outputs.
  Warmup has its own records, summary and WAV directory.

The client preloads references and serializes payloads before timing. Requests
use non-streaming `/v1/chat/completions`, `audio.ref_audio`, `max_tokens=256`,
temperature 0.7 and no generation seed. It uses the existing VoiceCloneOmni
prompt template for that reference field. Closed-loop workers replace each
completed request, with no artificial request-rate limit or retry.

HTTP E2E ends when the full HTTP body has been read, before JSON/base64/WAV
decoding. Audio-ready ends after decoding the full waveform. It is **not**
streaming first-chunk latency. Throughput divides successes or generated audio
seconds by cohort wall time, including fill/drain and failed request time.
Percentiles use successful requests only. WAVs and JSON are written after the
cohort so disk I/O is outside its wall-time measurement. These client metrics
are not GPU kernel time or server endpoint residence time.

Compare paired changes and their repetition range, HTTP p95/p99, output audio
duration and `length_finishes`. A shorter/truncated output can appear faster.
After shutting down serving, evaluate saved A/B WAVs with the same ASR model
and target texts, report WER and listen to matched samples for missing words,
repetition, artifacts and speaker consistency. Do not launch ASR concurrently
with timing. Valid WAV decoding alone does not establish audio quality.

### 5. Required component measurements for Talker claims

Run component benchmarks after the smoke test and before the full E2E sweep.
E2E alone cannot establish a Talker-stage speedup: Thinker, Code2Wav, scheduling
and variable output lengths can hide or imitate a small local improvement.
These component measurements test the changed operations with fixed synthetic
inputs. They do not time the entire Talker transformer or production stage.

#### Repetition penalty

Run this separately, with no serving process on the GPU:

```bash
cd "$CANDIDATE"
export VOCAB_SIZE="$(python -c 'import json,os; print(json.load(open(os.path.join(os.environ["MODEL"], "config.json")))["tts_config"]["num_audio_tokens"])')"
CUDA_VISIBLE_DEVICES=0 python -m benchmarks.benchmark_minicpm_talker_penalty \
  --device cuda --vocab-size "$VOCAB_SIZE" --batch-sizes 1 2 4 8 16 32 \
  --dtype float32 --samples 200 --warmup 50 --steps-per-sample 1 \
  --output "$RESULTS/penalty-isolated.json"
```

Repeat the penalty command four times with unique output filenames. Verify the
runtime logits dtype and repeat with that dtype if different. The
existing microbenchmark checks exact dense/sparse logits and measures
synchronized host wall time including packing/copies. It does not measure
prefill gains or E2E speedup. It compares a reproduced parent dense function to
the candidate's actual sparse function within the same process, alternating
their order per sample. Keep empty/disabled cases as controls, not speedup cases.

#### Prefill preparation

The new script invokes the actual `build_condition_embeddings` and
`before_prefill` methods from each checkout, without loading the transformer.
It uses checkpoint dimensions, seeded random embedding/projector weights and
fixed synthetic inputs. It checks outputs against reference math before timing.
The batch-1 packing case exercises the removed `torch.cat`; larger batches are
controls where concatenation is still required. Zero-length text isolates the
boundary-token construction; nonempty lengths include semantic projection.

```bash
for round in 1 2 3 4; do
  if [ $((round % 2)) -eq 1 ]; then
    order="baseline candidate"
  else
    order="candidate baseline"
  fi
  for variant in $order; do
    if [ "$variant" = baseline ]; then source="$BASELINE"; else source="$CANDIDATE"; fi
    (
      cd "$source"
      CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=4 PYTHONPATH="$source" \
        python "$SUITE/prefill.py" --config "$MODEL/config.json" \
        --dtype bfloat16 --output "$RESULTS/prefill-r${round}-${variant}.json"
    )
  done
done
```

Use Bash for this loop. Match the actual runtime embedding dtype; the default
above is an explicit BF16 test, not an assertion about runtime configuration.
Condition inputs default to CPU, so their transfer is included; prepared packing
inputs are on GPU, as produced by the real condition builder. Repeat with
`--input-device cuda` as a transfer-free condition-input control when useful.
Compare identical `(operation, text_tokens, batch)` cases and equal config,
harness hashes, dtype, input device and seed. Report paired median microseconds and percentage
change over four runs, plus the repetition range. Synchronization is inside
each timing; this is host wall time including launch/sync overhead, not pure
GPU kernel time. No KV-cache work, transformer prefill forward, retraction replay
or end-to-end Talker execution is included. Do not add these timings together
and call the sum total Talker latency.

#### Ablation and interpretation

For serving-level attribution, compare three revisions:

| Variant | Revision | Purpose |
|---|---|---|
| A | `12f7b6670cc236b63cca4f53a9a495b9aea93cf5` | Parent without this PR |
| B | `52a5524b` | Penalty changes only |
| C | `f9f8f335` | Penalty plus prefill changes |

The default run compares A/C. Create a separate B worktree and run A/B and B/C
with the same suite, inputs and configuration in separate output directories
if you need to distinguish the two changes in serving. A/C tests total PR
benefit, A/B isolates penalty changes, and B/C isolates prefill changes at the
whole-service level. Check the source diff for unrelated changes first.

To claim **total Talker-stage** speedup, additionally capture matched diagnostic
requests with the same temporary instrumentation on both revisions. Record
actual prefill/decode batch sizes, codec-token counts and stage residence time;
distinguish queue time from execution and normalize decode execution by actual
tokens/steps. This suite does not yet collect that stage-level evidence. A
faster component with unchanged E2E is a valid outcome; it is not proof of a
faster whole Talker or a failed component optimization.

Nsight captures, if needed, belong to separate diagnostic runs (for example
c1/c16 with 32 samples) and must not replace profiler-off throughput results.
This suite does not claim the issue's unpublished event instrumentation.

## Required AI handoff report

Return source SHAs and dirty status, artifact revisions, environment differences,
warmup provenance, reset policy, completeness/failures, and the path to all raw
evidence. Present the local paired A/B table first and the historical table
separately. Include output-length/truncation and audio-quality findings. If
noise spans both improvement and regression, report the outcome as inconclusive.
Do not label a smoke run, a partial sweep, or a microbenchmark as an E2E win.
