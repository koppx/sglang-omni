# SPDX-License-Identifier: Apache-2.0
"""Run alternating, fresh-server A/B sweeps on a single H100."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

MODEL_REVISION = "503e754207c94da6bb26850b4469f367c9ea3582"
DATASET_REVISION = "8f5e1aa2a35d42f42e940074c1983358b9491f89"
CONCURRENCIES = (1, 2, 4, 8, 16, 32)


def capture(command: list[str], source: Path) -> str:
    return subprocess.check_output(command, cwd=source, text=True).strip()


def stop_server(server: subprocess.Popen) -> None:
    try:
        os.killpg(server.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        server.wait(timeout=20)
    except subprocess.TimeoutExpired:
        pass
    finally:
        try:
            os.killpg(server.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        server.wait(timeout=20)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True, help="Pinned HF snapshot")
    parser.add_argument("--meta", type=Path, required=True)
    parser.add_argument("--warmup-meta", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--gpu", default="0", help="One physical GPU index or UUID")
    parser.add_argument("--port", type=int, default=18000)
    parser.add_argument("--repeats", type=int, default=4)
    parser.add_argument("--samples", type=int, default=1088)
    parser.add_argument("--concurrencies", type=int, nargs="+", default=CONCURRENCIES)
    parser.add_argument("--startup-timeout", type=int, default=1200)
    arguments = parser.parse_args()
    if (
        arguments.repeats < 1
        or not 0 < arguments.samples <= 1088
        or min(arguments.concurrencies) < 1
        or len(set(arguments.concurrencies)) != len(arguments.concurrencies)
        or arguments.startup_timeout < 1
        or not 0 < arguments.port < 65536
    ):
        parser.error("Invalid repeats, samples, concurrency, timeout or port")
    if arguments.model.resolve().name != MODEL_REVISION:
        parser.error(f"Use the model snapshot at revision {MODEL_REVISION}")
    if not arguments.meta.is_file() or not arguments.warmup_meta.is_file():
        parser.error("Both local meta.lst files must exist")
    sources = {
        "baseline": arguments.baseline.resolve(),
        "candidate": arguments.candidate.resolve(),
    }
    if sources["baseline"] == sources["candidate"]:
        parser.error("Baseline and candidate must be separate checkouts")
    gpu = capture(
        [
            "nvidia-smi",
            "-i",
            arguments.gpu,
            "--query-gpu=name,uuid,memory.total,driver_version",
            "--format=csv,noheader",
        ],
        sources["candidate"],
    )
    if len(gpu.splitlines()) != 1 or "H100" not in gpu:
        parser.error(f"Expected exactly one H100, got: {gpu}")
    arguments.output = arguments.output.resolve()
    arguments.output.mkdir(parents=True, exist_ok=False)
    suite = Path(__file__).resolve().parent
    environment = os.environ.copy()
    environment.update(CUDA_VISIBLE_DEVICES=arguments.gpu, OMP_NUM_THREADS="4")
    environment.pop("SGLANG_OMNI_MINICPM_PROFILE", None)
    manifest = {
        "arguments": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in vars(arguments).items()
        },
        "gpu": gpu,
        "python": sys.version,
        "dependencies": capture(
            [sys.executable, "-m", "pip", "freeze"], sources["candidate"]
        ),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "nvidia_smi": capture(
            ["nvidia-smi", "-i", arguments.gpu, "-q"], sources["candidate"]
        ),
        "model_revision": MODEL_REVISION,
        "dataset_revision_expected": DATASET_REVISION,
        "reset_policy": "fresh server per variant, repetition and concurrency",
        "suite_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in suite.glob("*.py")
        },
        "sources": {},
    }
    for label, source in sources.items():
        environment["PYTHONPATH"] = str(source)
        imported = subprocess.check_output(
            [sys.executable, "-c", "import sglang_omni; print(sglang_omni.__file__)"],
            cwd=source,
            env=environment,
            text=True,
        ).strip()
        if not Path(imported).resolve().is_relative_to(source):
            raise RuntimeError(f"Wrong import path for {label}: {imported}")
        manifest["sources"][label] = {
            "path": str(source),
            "revision": capture(["git", "rev-parse", "HEAD"], source),
            "status": capture(["git", "status", "--porcelain"], source),
            "diff": capture(["git", "diff", "HEAD", "--binary"], source),
            "minicpm_source_sha256": {
                str(path.relative_to(source)): hashlib.sha256(
                    path.read_bytes()
                ).hexdigest()
                for path in sorted(
                    (source / "sglang_omni/models/minicpm_o").rglob("*.py")
                )
            },
        }
    (arguments.output / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n"
    )
    for repetition in range(1, arguments.repeats + 1):
        order = (
            ("baseline", "candidate") if repetition % 2 else ("candidate", "baseline")
        )
        for concurrency in arguments.concurrencies:
            for label in order:
                source = sources[label]
                environment["PYTHONPATH"] = str(source)
                point = arguments.output / f"r{repetition}-c{concurrency}-{label}"
                point.mkdir()
                with socket.socket() as probe:
                    probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    probe.bind(("127.0.0.1", arguments.port))
                command = [
                    sys.executable,
                    "-m",
                    "sglang_omni.cli",
                    "serve",
                    "--model-path",
                    str(arguments.model.resolve()),
                    "--model-name",
                    "MiniCPM-o-4_5",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    str(arguments.port),
                    "--thinker.factory.max_seq_len",
                    "8192",
                    "--thinker.engine.mem_fraction_static",
                    "0.55",
                    "--talker.engine.mem_fraction_static",
                    "0.15",
                ]
                (point / "command.json").write_text(
                    json.dumps(command, indent=2) + "\n"
                )
                print(f"Running {point.name}", flush=True)
                with (point / "server.log").open("x") as log:
                    server = subprocess.Popen(
                        command,
                        cwd=source,
                        env=environment,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        start_new_session=True,
                    )
                    try:
                        deadline = time.monotonic() + arguments.startup_timeout
                        url = f"http://127.0.0.1:{arguments.port}"
                        while True:
                            if server.poll() is not None:
                                raise RuntimeError(
                                    f"Server exited; inspect {point / 'server.log'}"
                                )
                            if time.monotonic() >= deadline:
                                raise TimeoutError(f"Server startup timed out: {point}")
                            try:
                                with urllib.request.urlopen(
                                    url + "/v1/models", timeout=2
                                ) as response:
                                    if response.status == 200:
                                        break
                            except (urllib.error.URLError, TimeoutError):
                                time.sleep(1)
                        subprocess.run(
                            [
                                sys.executable,
                                str(suite / "collect.py"),
                                "--meta",
                                str(arguments.meta.absolute()),
                                "--warmup-meta",
                                str(arguments.warmup_meta.absolute()),
                                "--url",
                                url + "/v1/chat/completions",
                                "--output",
                                str(point / "client"),
                                "--concurrency",
                                str(concurrency),
                                "--samples",
                                str(arguments.samples),
                            ],
                            cwd=source,
                            env=environment,
                            check=True,
                        )
                    finally:
                        stop_server(server)
    subprocess.run(
        [sys.executable, str(suite / "compare.py"), str(arguments.output)], check=True
    )


if __name__ == "__main__":
    main()
