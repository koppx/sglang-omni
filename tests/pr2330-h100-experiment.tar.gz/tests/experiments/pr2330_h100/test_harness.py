# SPDX-License-Identifier: Apache-2.0
"""Test measurement and comparison contracts without CUDA or model weights."""

from __future__ import annotations

import asyncio
import base64
import io
import json
from pathlib import Path

import numpy as np
import pytest
import soundfile as sf
from aiohttp import web
from collect import PreparedSample, measure, prepare, summarize
from compare import METRICS, build_report


def test_snapshot_symlink_preserves_relative_audio(tmp_path: Path) -> None:
    snapshot = tmp_path / "snapshot"
    snapshot.mkdir()
    reference = snapshot / "reference.wav"
    reference.write_bytes(b"reference-content")
    blob = tmp_path / "metadata-blob"
    blob.write_text(
        "".join(
            f"sample-{index}|reference words|reference.wav|target words\n"
            for index in range(1088)
        )
    )
    meta = snapshot / "meta.lst"
    meta.symlink_to(blob)
    samples = prepare(meta, 8, "en")
    assert len(samples) == 8
    payload = json.loads(samples[0].payload)
    assert payload["stream"] is False
    assert payload["max_tokens"] == 256
    assert payload["temperature"] == 0.7
    assert "audios" not in payload
    assert (
        base64.b64decode(payload["audio"]["ref_audio"].split(",", 1)[1])
        == reference.read_bytes()
    )


def test_closed_loop_measurement_and_failures() -> None:
    async def exercise() -> None:
        buffer = io.BytesIO()
        sf.write(buffer, np.zeros(1600, dtype=np.float32), 16000, format="WAV")
        encoded = base64.b64encode(buffer.getvalue()).decode()
        active = 0
        peak = 0
        received = []

        async def handle(request: web.Request) -> web.Response:
            nonlocal active, peak
            payload = await request.json()
            received.append(payload["request_id"])
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.01)
            active -= 1
            if payload["request_id"] == "bad-http":
                return web.Response(status=500, text="injected failure")
            audio = (
                "invalid base64" if payload["request_id"] == "bad-audio" else encoded
            )
            return web.json_response(
                {
                    "id": "chatcmpl-" + payload["request_id"],
                    "choices": [
                        {"message": {"audio": {"data": audio}}, "finish_reason": "stop"}
                    ],
                }
            )

        application = web.Application()
        application.router.add_post("/v1/chat/completions", handle)
        runner = web.AppRunner(application)
        await runner.setup()
        site = web.TCPSite(runner, "127.0.0.1", 0)
        await site.start()
        port = runner.addresses[0][1]
        samples = [
            PreparedSample(
                sample_id=request_id,
                target_text="Complete target text",
                reference_sha256="reference",
                request_id=request_id,
                payload=json.dumps({"request_id": request_id}).encode(),
            )
            for request_id in ("one", "two", "bad-http", "bad-audio", "three")
        ]
        try:
            records, waveforms, wall_s = await measure(
                samples, 2, f"http://127.0.0.1:{port}/v1/chat/completions", 10
            )
        finally:
            await runner.cleanup()
        assert peak == 2
        assert received == [sample.request_id for sample in samples]
        assert len(records) == 5
        assert sum(bool(waveform) for waveform in waveforms) == 3
        for record in records:
            if not record.error:
                assert record.start_ns <= record.body_ns <= record.ready_ns
                assert 0 < record.http_s <= record.ready_s <= wall_s
                assert record.audio_s == pytest.approx(0.1)
                assert record.response_id == "chatcmpl-" + record.request_id
        summary = summarize(records, wall_s)
        assert summary["successful"] == 3
        assert summary["failed"] == 2
        assert summary["req_s"] == pytest.approx(3 / wall_s)
        assert summary["audio_s_s"] == pytest.approx(0.3 / wall_s)

    asyncio.run(exercise())


def write_results(root: Path) -> None:
    manifest = {
        "arguments": {"samples": 1088, "concurrencies": [1], "repeats": 2},
        "gpu": "test H100",
        "sources": {
            "baseline": {"revision": "before"},
            "candidate": {"revision": "after"},
        },
    }
    (root / "manifest.json").write_text(json.dumps(manifest))
    for repetition in (1, 2):
        for label, value in (("baseline", 2.0), ("candidate", 3.0)):
            result = {metric: value for metric in METRICS}
            result.update(
                attempted=1088,
                successful=1088,
                failed=0,
                concurrency=1,
                smoke=False,
                inputs_sha256="same-inputs",
                length_finishes=0,
                audio_total_s=1088 * value,
            )
            directory = root / f"r{repetition}-c1-{label}" / "client"
            directory.mkdir(parents=True)
            (directory / "measured.json").write_text(json.dumps(result))


def test_paired_report(tmp_path: Path) -> None:
    write_results(tmp_path)
    report = build_report(tmp_path)
    assert "+50.00 [+50.00, +50.00]" in report
    assert "Historical Reference Only" in report
    assert "1088 / 1088" in report


@pytest.mark.parametrize(
    "field,value", [("failed", 1), ("inputs_sha256", "different"), ("successful", 8)]
)
def test_reject_invalid_comparison(
    tmp_path: Path, field: str, value: int | str
) -> None:
    write_results(tmp_path)
    path = tmp_path / "r2-c1-candidate/client/measured.json"
    result = json.loads(path.read_text())
    result[field] = value
    path.write_text(json.dumps(result))
    with pytest.raises(ValueError):
        build_report(tmp_path)


def test_reject_missing_point(tmp_path: Path) -> None:
    write_results(tmp_path)
    (tmp_path / "r2-c1-candidate/client/measured.json").unlink()
    with pytest.raises(FileNotFoundError):
        build_report(tmp_path)
