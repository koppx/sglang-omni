# SPDX-License-Identifier: Apache-2.0
"""Temporary PR2330 experiment: report A/B and historical comparisons."""

from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path

METRICS = {
    "req_s": "Request throughput (req/s)",
    "audio_s_s": "Audio throughput (audio s/s)",
    "http_mean_s": "HTTP mean (s)",
    "http_p50_s": "HTTP p50 (s)",
    "http_p95_s": "HTTP p95 (s)",
    "http_p99_s": "HTTP p99 (s)",
    "ready_mean_s": "Audio-ready mean (s)",
    "ready_p95_s": "Audio-ready p95 (s)",
    "audio_mean_s": "Output audio mean (s)",
}


def build_report(root: Path) -> str:
    manifest = json.loads((root / "manifest.json").read_text())
    arguments = manifest["arguments"]
    smoke = arguments["samples"] != 1088
    title = (
        "Smoke test only; not a performance conclusion"
        if smoke
        else "MiniCPM-o H100 A/B"
    )
    lines = [
        f"# {title}",
        "",
        f"Baseline: `{manifest['sources']['baseline']['revision']}`",
        f"Candidate: `{manifest['sources']['candidate']['revision']}`",
        "",
        f"GPU: {manifest['gpu']}",
        "",
        "Fresh server at every point. Generation RNG is not fixed. "
        "Audio-ready is full-response readiness, not streaming TTFA.",
        "",
        "Values are medians across repetitions, not pooled request quantiles. "
        "Delta is the median paired (candidate / baseline - 1) percent; "
        "the bracket gives its min/max across repetitions. "
        "Positive throughput and negative latency deltas are improvements.",
        "",
        "| c | Metric | Baseline | Candidate | Paired delta % [min, max] |",
        "|---|---|---:|---:|---:|",
    ]
    historical = json.loads((Path(__file__).parent / "issue2273.json").read_text())
    history_lines = [
        "",
        "## Historical Reference Only",
        "",
        f"Source: {historical['source']}",
        "",
        historical["warning"],
        "",
        "Candidate medians vs published single-run observations. "
        "These deltas do not isolate PR2330's effect.",
        "",
        "| c | Metric | Issue #2273 | Candidate | Delta % |",
        "|---|---|---:|---:|---:|",
    ]
    input_hashes = set()
    quality_lines = [
        "",
        "## Completion Checks",
        "",
        "| Point | Success / attempted | Length finishes | Audio seconds |",
        "|---|---:|---:|---:|",
    ]
    for concurrency in arguments["concurrencies"]:
        paired = []
        for repetition in range(1, arguments["repeats"] + 1):
            pair = {}
            for label in ("baseline", "candidate"):
                point = f"r{repetition}-c{concurrency}-{label}"
                path = root / point / "client" / "measured.json"
                result = json.loads(path.read_text())
                if (
                    result["failed"] != 0
                    or result["successful"] != arguments["samples"]
                    or result["attempted"] != arguments["samples"]
                    or result["concurrency"] != concurrency
                    or result["smoke"] != smoke
                ):
                    raise ValueError(
                        f"Invalid or failed point: {point}; no speedup report"
                    )
                input_hashes.add(result["inputs_sha256"])
                pair[label] = result
                quality_lines.append(
                    f"| {point} | {result['successful']} / {result['attempted']} | "
                    f"{result['length_finishes']} | {result['audio_total_s']:.3f} |"
                )
            paired.append(pair)
        reference = next(
            (
                point
                for point in historical["points"]
                if point["concurrency"] == concurrency
            ),
            None,
        )
        for metric, label in METRICS.items():
            baseline = [pair["baseline"][metric] for pair in paired]
            candidate = [pair["candidate"][metric] for pair in paired]
            if min(baseline + candidate) <= 0:
                raise ValueError(f"Nonpositive metric: {metric}")
            deltas = [
                (after / before - 1) * 100 for before, after in zip(baseline, candidate)
            ]
            candidate_median = statistics.median(candidate)
            lines.append(
                f"| {concurrency} | {label} | {statistics.median(baseline):.4f} | "
                f"{candidate_median:.4f} | {statistics.median(deltas):+.2f} "
                f"[{min(deltas):+.2f}, {max(deltas):+.2f}] |"
            )
            if reference is not None and metric in reference:
                old = reference[metric]
                history_lines.append(
                    f"| {concurrency} | {label} | {old:.4f} | "
                    f"{candidate_median:.4f} | {(candidate_median / old - 1) * 100:+.2f} |"
                )
    if len(input_hashes) != 1:
        raise ValueError("Input manifests differ across points; no speedup report")
    if not smoke:
        lines.extend(history_lines)
    lines.extend(quality_lines)
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "Inspect output lengths, truncation, WER and listening samples before claiming "
            "an improvement. Repetition ranges are descriptive, not confidence intervals. "
            "No quality pass or statistical significance is inferred by this script.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    arguments = parser.parse_args()
    report = build_report(arguments.results)
    path = arguments.results / "comparison.md"
    path.write_text(report)
    print(f"Saved {path}")


if __name__ == "__main__":
    main()
